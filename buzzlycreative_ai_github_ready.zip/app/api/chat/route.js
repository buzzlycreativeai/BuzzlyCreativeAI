// API route placeholder
export async function POST(req){ return Response.json({msg:'ok'}) }